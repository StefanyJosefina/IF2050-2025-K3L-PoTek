package id.sti.potek.dao;

import id.sti.potek.model.Ulasan;
import id.sti.potek.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UlasanDAO {

    public void insertUlasan(Ulasan ulasan) {
        String sql = "INSERT INTO ulasan (idUlasan, idUser, idKamar, rating, komentar) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String idUlasan = "UL" + System.currentTimeMillis(); // ID unik berbasis timestamp

            stmt.setString(1, idUlasan);
            stmt.setString(2, "U" + ulasan.getIdUser()); // tambahkan prefix U
            stmt.setString(3, ulasan.getIdKamar());
            stmt.setDouble(4, ulasan.getRating());
            stmt.setString(5, ulasan.getKomentar());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Ulasan> getAllByKamar(String idKamar) {
        List<Ulasan> list = new ArrayList<>();
        String sql = "SELECT u.rating, u.komentar, us.nama FROM ulasan u JOIN user us ON u.idUser = us.idUser WHERE u.idKamar = ? ORDER BY u.rating DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, idKamar);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(new Ulasan(
                        rs.getString("nama"),
                        idKamar,
                        rs.getDouble("rating"),
                        rs.getString("komentar")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}