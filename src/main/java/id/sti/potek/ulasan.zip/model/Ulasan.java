package id.sti.potek.model;

public class Ulasan {
    private int idUser;
    private String namaUser;
    private String idKamar;
    private double rating;
    private String komentar;

    // Constructor untuk insert
    public Ulasan(int idUser, String idKamar, double rating, String komentar) {
        this.idUser = idUser;
        this.idKamar = idKamar;
        this.rating = rating;
        this.komentar = komentar;
    }

    // Constructor untuk tampilkan ulasan
    public Ulasan(String namaUser, String idKamar, double rating, String komentar) {
        this.namaUser = namaUser;
        this.idKamar = idKamar;
        this.rating = rating;
        this.komentar = komentar;
    }

    public int getIdUser() { return idUser; }
    public String getIdKamar() { return idKamar; }
    public double getRating() { return rating; }
    public String getKomentar() { return komentar; }
    public String getNamaUser() { return namaUser; }
}