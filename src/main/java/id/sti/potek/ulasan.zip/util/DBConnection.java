package id.sti.potek.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String DB_URL = "jdbc:mariadb://localhost:3306/potek";
    private static final String DB_USER = "root"; // ganti kalau pakai user lain
    private static final String DB_PASS = "";     // ganti sesuai password MySQL/MariaDB kamu

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.mariadb.jdbc.Driver"); // pastikan library JDBC MariaDB sudah di `build.gradle`
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MariaDB tidak ditemukan", e);
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }
}