package id.sti.potek.ui;

import id.sti.potek.controller.TiketController;
import id.sti.potek.model.Tiket;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class TiketCariView {

    public void start(Stage stage) {
        TextField asalField = new TextField();
        asalField.setPromptText("Asal");

        TextField tujuanField = new TextField();
        tujuanField.setPromptText("Tujuan");

        TextField tanggalField = new TextField();
        tanggalField.setPromptText("Tanggal (yyyy-mm-dd)");

        Button cariBtn = new Button("Cari Tiket");

        VBox root = new VBox(10, asalField, tujuanField, tanggalField, cariBtn);
        root.setPadding(new Insets(20));

        cariBtn.setOnAction(e -> {
            String asal = asalField.getText();
            String tujuan = tujuanField.getText();
            String tanggal = tanggalField.getText();

            TiketController controller = new TiketController();
            try {
                List<Tiket> hasil = controller.cariTiket(asal, tujuan, tanggal);
                if (hasil.isEmpty()) {
                    showAlert("Tiket tidak ditemukan");
                } else {
                    new TiketPilihView().start(stage, hasil);
                }
            } catch (Exception ex) {
                showAlert("Error: " + ex.getMessage());
            }
        });

        stage.setScene(new Scene(root, 400, 250));
        stage.setTitle("Cari Tiket");
        stage.show();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(msg);
        alert.show();
    }
}
