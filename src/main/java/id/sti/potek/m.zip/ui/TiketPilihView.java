
package id.sti.potek.ui;

import id.sti.potek.model.Tiket;
import id.sti.potek.dao.PemesananDAO;
import id.sti.potek.dao.TiketDAO;
import javafx.collections.FXCollections;
import javafx.geometry.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.*;

public class TiketPilihView {
    private final Map<Integer, Boolean> ketersediaanKursi = new HashMap<>();

    public void start(Stage stage, List<Tiket> hasil) {
        // Dummy data kursi: true = tersedia, false = booked
        for (int i = 1; i <= 9; i++) {
            ketersediaanKursi.put(i, i != 7); // Kursi 7 booked
        }

        ListView<Tiket> listView = new ListView<>(FXCollections.observableArrayList(hasil));
        listView.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Tiket item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    String text = item.getJam() + " (Estimasi 3 jam)\n";
                    if (item.getTersediaKursi() == 0) {
                        text += "Kursi Tidak Tersedia";
                    } else {
                        text += "Tersedia " + item.getTersediaKursi() + " Kursi";
                    }
                    setText(text);
                }
            }
        });

        // Grid kursi
        GridPane seatGrid = new GridPane();
        seatGrid.setHgap(10);
        seatGrid.setVgap(10);
        seatGrid.setPadding(new Insets(10));

        Label seatLabel = new Label("Ketersediaan");

        int col = 0, row = 0;
        for (int i = 1; i <= 9; i++) {
            Button btn = new Button(String.valueOf(i));
            btn.getStyleClass().add("seat-button");

            boolean available = ketersediaanKursi.getOrDefault(i, true);
            btn.getStyleClass().add(available ? "seat-empty" : "seat-booked");
            btn.setDisable(!available);

            seatGrid.add(btn, col, row);
            col++;
            if (i % 3 == 0) {
                col = 0;
                row++;
            }
        }

        Label supir = new Label("supir");
        supir.getStyleClass().add("supir-label");
        seatGrid.add(supir, 2, 0);

        Button pesanBtn = new Button("Pesan");
        pesanBtn.getStyleClass().add("pesan-button");

        VBox jadwalBox = new VBox(10, new Label("Jadwal"), listView);
        VBox seatBox = new VBox(10, seatLabel, seatGrid, pesanBtn);
        HBox root = new HBox(20, jadwalBox, seatBox);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 800, 400);
        scene.getStylesheets().add(getClass().getResource("/styles/tiketpilih.css").toExternalForm());

        stage.setTitle("Pilih Tiket");
        stage.setScene(scene);
        stage.show();
    }
}
