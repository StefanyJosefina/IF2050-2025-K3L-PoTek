package java.id.sti.potek.model;

public class User {
    
}
